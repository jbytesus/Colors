<?php //this function will be called in the next section
function advanced_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
 
<br/><br/>

<div class="comment-author vcard">
     <div class="avatar"><?php echo get_avatar( $comment, $size = '65', $default = ''); ?></div>

<br/>
<span class="author"><?php comment_author_link() ?></span><br /><span class=" <?php echo get_avatar( $comment, 65 ); ?><br /><span class="time"><?php comment_time() ?></span> on <a href="#comment-<?php comment_ID() ?>" title=""><?php comment_date('F jS, Y') ?></a><br/><br/>
	
	</div>
  
     <div class="clear"></div>
    

     <?php if ($comment->comment_approved == '0') : ?>
       <em><?php _e('Your comment is awaiting moderation.') ?></em>
       <br /> 
     <?php endif; ?>
 
     <div class="comment-text">	
         <?php comment_text() ?>
     </div>
 
   <div class="reply">
      <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
   </div><br/>
<h3></h3>

   <div class="clear"></div>
<?php } ?>