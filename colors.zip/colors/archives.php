<?php

	/*

	Template Name: Archive

	*/

	?>

	<?php get_header(); ?>
<div class="column-right">
	    <div id="content">
<div class="post">   
<h1><?php the_title(); ?></h1>

<ul>
 <?php wp_get_archives('type=monthly'); ?>
</ul>
</div>
</div>

 </div><!-- end content-left -->

<?php get_sidebar(); ?>

<div class="clear"></div>

<?php get_footer(); ?>