<!DOCTYPE html>
<html lang="en">
<head>
<title><?php bloginfo('name'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>"  type="text/css" media="all" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="stylesheet" href="http://jaymee.blog/font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="http://jaymee.blog/font-awesome-4.7.0/css/font-awesome">
<script src="/scripts/modernizr.js" type="text/javascript"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
</head>
<body>
	
	<div id="container">
		<div id="header">
	<div id="title">
		Jaymee.blog
	</div>
	</div>
	
<div id="navigation">
 <a href="/">Home</a> 
		<a href="/about">About</a> 
		<a href="/archives">Archives</a> 
		<a href="/links">Links</a> 
		<a href="http://jaymee.blog/contact.php" target="_blank">Contact</a>
        
	</div>
	 


	
	
	<div id="content">
		

	
	




	
		
						
			