

<!DOCTYPE html>

<html lang="en">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>404 Error Page &#8212;404</title>
<link href="http://jaymee.blog/errorstyle.css" rel="stylesheet" type="text/css">
<link href="http://jaymee.blog/wp-content/themes/consideration/style.css" rel="stylesheet" type="text/css">
<script src="/scripts/modernizr.js" type="text/javascript"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
</head>
<body>

	<h1>404 Error Page!</h1>	

 <div id="header"></div>  

<div id="container">

<div id="content">


<p class="centered"><img src="/images/homer.png" alt="404 Error Page!" /></p>
<br/><br/><br/>

<h2>Do'Error!</h2><br/>
It looks as if Homer's asleep on the job, once again! Man, I really need to re-think as to who I hire next time to help me get the job done!<br/>

<br/>
Until that actually happens, the page you're looking for or whatever it was you were looking for does not exist and this could be because:<br/>
<br/>

1.) The page never existed.<br/>
2.) The page is still under construction.<br/>
3.) The Url to the page was typed incorrectly.<br/>
4.) The page is dead, broken, or was actually eaten by Homer while intoxicated.<br/>
5.) The page had been moved to a new location and no one was informed thanks to the lazy workers I hired to help me.<br/>
<br/>
	
<h2>What now?!</h2><br/>
If you still 100% believe that there was such a page that existed and are convinced it existed, please <a href="http://jaymee.blog/contact.php" target="_blank">contact Jamie</a> to fix this problem immediately. Otherwise, you'll just end up getting the same error page. I'm sure by now you're scarred for life seeing Homer half naked and drooling, right?<br/>
<br/>
	
	
<h2>Search The Site!</h2>
Can't seem to find a particular post that you know I've written, or a missing page altogether? Please use the search form below to navigate around <i>jaymee.blog</i>. If that's the case, please <a href="http://jaymee.blog/contact.php" target="_blank">contact me</a> via the contact form and let me know! Or you can simply email me at <i>dudeilostmykeys[at]gmail.com</i><br/> Good luck with your search!<br/>
<br/>

	<form action="/search" method="get">
  <input id="search-box" type="text" value="Search..." onfocus="if(this.value == 'Search...') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Search...'; }"/> <button id="search-btn" type="submit"><i class="fa fa-search"></i></button>
</form>
</div>
</div>


	
	  
	<?php get_footer(); ?>