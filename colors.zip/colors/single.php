<?php get_header(); ?>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

<div class="column-left">
<div class="post-thumbnail">
<?php if ( has_post_thumbnail() ) : ?>
<?php the_post_thumbnail( 'thumbnail', array( 'class' => 'alignleft' )); ?>
<?php endif; ?>	
</div>
<div class="categories">
<p><span><i class="fa fa-pencil"  ></i>
<?php the_date(' F j, Y'); ?></span>
<p><span><i class="fa fa-tag" ></i><?php the_category(', '); ?></span></p>

</div>
</div>

	
<div class="column-right">
<div class="post-title"> <?php the_title(); ?></div> 

<?php the_content(); ?>
</div>
</div>	



					


<?php endwhile; else: ?>
		<h1>Not Found</h1>
		<p>Sorry, but the page you requested cannot be found. If you feel this is an error, let me know.</p>
<?php endif; ?>

<?php get_footer(); ?>