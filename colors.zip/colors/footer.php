</div>
<div class="older-entries"><?php next_posts_link( '« Older Entries' ); ?></div>

<div class="newer-entries"><?php previous_posts_link( 'Newer Entries » ' ); ?></div
<div class="column-footer">
<div id="footer">
<p class="centered">
Copyright &copy; 2017-2018 <a href="http://jaymee.blog" target="_blank">Jamie</a>

	&bull; Hosted by: <a href="http://www.candyrain.org" target="_blank">Candyrain.org</a> &bull; All rights reserved. <a href="#">&#x21E1; To Top</a></p>
</div>	
</div>

	

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script>
		$("#main-menu--toggle").click(function(){
			$("#main-menu--expanded").slideToggle("slow");
		});
</script>

<script>
jQuery(document).ready(function($) {
    $(window).scroll(function () {
        if ($(window).scrollTop() > 100) { 
            $('header').addClass('shrink');
        }
        else{
            $('header').removeClass('shrink');
        }
    });
});
</script>
<script src="http://jaymee.blog/scripts/main.js"></script>	
</body>
</html>  